from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional

app = FastAPI()

students = {}
tests = {}
test_results: List[dict] = []

class Student(BaseModel):
    id: int
    name: str
    email: str
    tests_taken: List[int] = list

class Test(BaseModel):
    id: int
    name: str
    max_score: int

class TestResult(BaseModel):
    student_id: int
    test_id: int
    score: int

class ResponseMessage(BaseModel):
    message: str

@app.post("/students/")
def create_student(student: Student):
    if student.id in students:
        return "Student already exists"
    students[student.id] = student.dict()
    return student

@app.get("/students/{student_id}")
def student_id(student_id: int):
    if student_id not in students:
        return 'student id not found'
    return students[student_id]

@app.get('/students/')
def all_students_get():
    return list(students.values())

@app.post('/test/')
def create_test(test: Test):
    if test.id in tests:
        return 'test already exists'
    tests[test.id] = test.dict()
    return test

@app.get('/tests/{test_id}')
def get_test_by_id(test_id: int):
    if test_id not in tests:
        return 'test not found'
    return tests[test_id]

@app.get('/tests')
def all_tests_get():
    return list(tests.values())

@app.post("/results/")
def submit_test_result(result: TestResult):
    if result.student_id not in students:
        return "Student not found"
    if result.test_id not in tests:
        return "Test not found"
    test_results.append(result.dict())
    return result

@app.get("/results/student/{student_id}/")
def get_results_for_student(student_id: int):
    results = [r for r in test_results if r["student_id"] == student_id]
    return results

@app.get("/results/test/{test_id}/")
def get_results_for_test(test_id: int):
    results = [r for r in test_results if r["test_id"] == test_id]
    return results

@app.get("/results/test/{test_id}/average")
def get_average_score(test_id: int):
    scores = [r["score"] for r in test_results if r["test_id"] == test_id]
    if not scores:
        return "no results found for this test"
    return {"average_score": sum(scores) / len(scores)}

@app.get("/results/test/{test_id}/highest")
def get_highest_score(test_id: int):
    scores = [r["score"] for r in test_results if r["test_id"] == test_id]
    if not scores:
        return "no results found for this test"
    return {"highest_score": max(scores)}

@app.delete("/students/{student_id}/")
def delete_student(student_id: int):
    if student_id not in students:
        return "student not found"
    del students[student_id]
    return {"message": "Student deleted successfully"}















