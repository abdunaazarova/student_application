import pytest
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)

def test_create_student():
    response = client.post("/students/", json={"id": 1, "name": "John Doe", "email": "john@example.com", "tests_taken": []})
    assert response.status_code == 200
    assert response.json()["name"] == "John Doe"

def test_create_duplicate_student():
    response = client.post("/students/", json={"id": 1, "name": "John Doe", "email": "john@example.com", "tests_taken": []})
    assert response.status_code == 200
    assert response.json() == "Student already exists"

def test_get_student():
    response = client.get("/students/1")
    assert response.status_code == 200
    assert response.json()["name"] == "John Doe"

def test_get_non_existent_student():
    response = client.get("/students/99")
    assert response.status_code == 200
    assert response.json() == "student id not found"

def test_create_exam():
    response = client.post("/test/", json={"id": 1, "name": "Math Test", "max_score": 100})
    assert response.status_code == 200
    assert response.json()["name"] == "Math Test"

def test_create_duplicate_exam():
    response = client.post("/test/", json={"id": 1, "name": "Math Test", "max_score": 100})
    assert response.status_code == 200
    assert response.json() == "test already exists"

def test_submit_test_result():
    response = client.post("/results/", json={"student_id": 1, "test_id": 1, "score": 80})
    assert response.status_code == 200
    assert response.json()["score"] == 80

def test_get_results_for_student():
    response = client.get("/results/student/1/")
    assert response.status_code == 200
    assert len(response.json()) > 0

def test_get_results_for_test():
    response = client.get("/results/test/1/")
    assert response.status_code == 200
    assert len(response.json()) > 0

def test_get_average_score():
    response = client.get("/results/test/1/average")
    assert response.status_code == 200
    assert "average_score" in response.json()

def test_get_highest_score():
    response = client.get("/results/test/1/highest")
    assert response.status_code == 200
    assert "highest_score" in response.json()

def test_delete_student():
    response = client.delete("/students/1/")
    assert response.status_code == 200
    assert response.json() == {"message": "Student deleted successfully"}
